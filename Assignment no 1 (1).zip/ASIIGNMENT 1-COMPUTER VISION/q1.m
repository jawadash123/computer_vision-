%% 1) READS AND WRITES AN IMAGE

%mecca
im1 = imread("mecca06.pgm");  %reads an image
figure
imshow(im1); %shows the image
imwrite(im1,"mecca06_OUT.pgm"); %writes the image

%owl
im1 = imread("owl.pgm");  %reads an image
figure
imshow(im1); %shows the image
imwrite(im1,"owl_OUT.pgm"); %writes the image
