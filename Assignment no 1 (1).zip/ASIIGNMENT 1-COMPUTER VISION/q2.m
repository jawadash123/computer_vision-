% Read images into matrices
im1 = imread("owl.pgm");

figure
    imshow(im1);

% Part (b) - Add 50 to each pixel using for loop 
for i = 1 : size(im1, 1)
    for j = 1 : size(im1, 2)
        %checks if pixel value is lesser than 255, else put 255 in it
        if im1(i,j)+50<255
           im1(i,j) = im1(i,j) + 50;
        end
    end   

end
figure
   imshow(im1);
   imwrite(im1,"owl_IntensityInc50_Out.pgm")
   % Part (c) - Apply log transformation (Base 10) using for loop
   for i = 1 : size(im1, 1)
    for j = 1 : size(im1, 2)
        % Apply log base 10 transformation and normalize to 0-255
        im1(i,j) = uint8(255 * log10(double(im1(i,j)) + 1) / log10(256));
    end   
end

% Save the transformed image
imwrite(im1, "owl_Log_Out.pgm");
figure
   imshow(im1);


   % Part - D Add 20 40 60 80 100 to each pixel 
% Read input image
im1 = imread("owl.pgm");

%  Add 20 
im1_20 = im1;
for i = 1:size(im1, 1)
    for j = 1:size(im1, 2)
        if im1(i, j) + 20 < 255
            im1_20(i, j) = im1(i, j) + 20;
        else
            im1_20(i, j) = 255;
        end
    end
end
imwrite(im1_20, "owl_Intensity20_Out.pgm");
figure, imshow(im1_20);

% - Add 40 -
im1_40 = im1;
for i = 1:size(im1, 1)
    for j = 1:size(im1, 2)
        if im1(i, j) + 40 < 255
            im1_40(i, j) = im1(i, j) + 40;
        else
            im1_40(i, j) = 255;
        end
    end
end
imwrite(im1_40, "owl_Intensity40_Out.pgm");
figure, imshow(im1_40);

% - Add 60 -
im1_60 = im1;
for i = 1:size(im1, 1)
    for j = 1:size(im1, 2)
        if im1(i, j) + 60 < 255
            im1_60(i, j) = im1(i, j) + 60;
        else
            im1_60(i, j) = 255;
        end
    end
end
imwrite(im1_60, "owl_Intensity60_Out.pgm");
figure, imshow(im1_60);

% - Add 80 -
im1_80 = im1;
for i = 1:size(im1, 1)
    for j = 1:size(im1, 2)
        if im1(i, j) + 80 < 255
            im1_80(i, j) = im1(i, j) + 80;
        else
            im1_80(i, j) = 255;
        end
    end
end
imwrite(im1_80, "owl_Intensity80_Out.pgm");
figure, imshow(im1_80);

% - Add 100 -
im1_100 = im1;
for i = 1:size(im1, 1)
    for j = 1:size(im1, 2)
        if im1(i, j) + 100 < 255
            im1_100(i, j) = im1(i, j) + 100;
        else
            im1_100(i, j) = 255;
        end
    end
end
imwrite(im1_100, "owl_Intensity100_Out.pgm");
figure, imshow(im1_100);

%Part E Repeat part b and part c without using for loop

% Read input image
im1 = imread("owl.pgm");
% these are the partse of q 2e
% - Part B Increase Intensity Without Loop -
im1_50 = im1 + 50;          % Add 50 to each pixel
im1_50(im1_50 > 255) = 255; % If any value exceeds 255, set it to 255
imwrite(im1_50, "owl_IntensityInc50_Out.pgm");
figure,imshow(im1_50)

% - Part C Log Transformation Without Loop -
im1_log = uint8(255 * log10(double(im1) + 1) / log10(256));  
imwrite(im1_log, "owl_Log_Out.pgm");
figure,imshow(im1_log)

