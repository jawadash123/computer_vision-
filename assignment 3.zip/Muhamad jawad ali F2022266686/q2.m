% Read images with updated filenames
original = imread('Original-min-min.JPG');
theft1 = imread('theft1-min-min.JPG');
theft2 = imread('theft2-min-min.JPG');

% Drop alternate columns (horizontal reduction by 2)
original_halfH = original(:, 1:2:end, :);
theft1_halfH = theft1(:, 1:2:end, :);
theft2_halfH = theft2(:, 1:2:end, :);

% Drop alternate rows (vertical reduction by 2)
original_reduced = original_halfH(1:2:end, :, :);
theft1_reduced = theft1_halfH(1:2:end, :, :);
theft2_reduced = theft2_halfH(1:2:end, :, :);

% Save output images
imwrite(original_reduced, 'Original_reduced.JPG');
imwrite(theft1_reduced, 'theft1_reduced.JPG');
imwrite(theft2_reduced, 'theft2_reduced.JPG');

% Display sizes (just to confirm)
disp(['Original reduced size: ', mat2str(size(original_reduced))]);
disp(['Theft1 reduced size: ', mat2str(size(theft1_reduced))]);
disp(['Theft2 reduced size: ', mat2str(size(theft2_reduced))]);

% Display reduced images
figure;
subplot(1,3,1); imshow(original_reduced); title('Original Reduced');
subplot(1,3,2); imshow(theft1_reduced); title('Theft1 Reduced');
subplot(1,3,3); imshow(theft2_reduced); title('Theft2 Reduced');
