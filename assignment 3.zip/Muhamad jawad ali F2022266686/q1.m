% Read original and theft images
original = imread('Original-min-min.JPG');
theft1 = imread('theft1-min-min.JPG');


% Convert to grayscale
grayOriginal = rgb2gray(original);
grayTheft1 = rgb2gray(theft1);

% Compute absolute difference manually
diff1 = abs(double(grayOriginal) - double(grayTheft1));



% Display result
figure;
subplot(1,3,1); imshow(original); title('Original');
subplot(1,3,2); imshow(theft1); title('Theft Image');
subplot(1,3,3); imshow(stolenObject1); title('Stolen Object Detected');